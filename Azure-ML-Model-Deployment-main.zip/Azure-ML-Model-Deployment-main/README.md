This repo contains required code to deploy a trained ML model on Azure as endpoint.

Check this video for step-by-step explanation: https://youtu.be/VfTVIXiffBU

YouTube Channel (Siddhardhan): https://www.youtube.com/@Siddhardhan

Machine Learning Course in 60 Hours: https://youtube.com/playlist?list=PLfFghEzKVmjvII5ZcBnFWQOUjtUVdDnmo&si=EnSIkaIECMiOmarE
