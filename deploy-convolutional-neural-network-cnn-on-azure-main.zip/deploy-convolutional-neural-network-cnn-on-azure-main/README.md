# deploy-convolutional-neural-network-cnn-on-azure
This repository contains the required files and to deploy a trained Convolutional Neural network on Azure

Checkout this YouTube video for step-by-step guide: 
